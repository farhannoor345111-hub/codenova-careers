# CodeNova Careers — C++ Job Application Website

The website design is unchanged. The form is wired to the C++ backend at `/apply`.

## Why the old form showed an error
Opening `public/index.html` directly in Chrome (`file://...`) does not run the C++ server, so the browser cannot reach `/apply`.

## Run locally
1. Install a C++17 compiler.
2. Install `cpp-httplib`, `nlohmann/json`, and `libcurl`.
3. Build `backend/main.cpp`.
4. Run the resulting server from this project directory so `./public` is found.
5. Open `http://localhost:8080` in Chrome — **do not open index.html directly**.

## Gmail delivery
Set these environment variables before starting the server:

- `SMTP_USER` = the Gmail account used to send mail
- `SMTP_APP_PASSWORD` = a Gmail App Password (not the normal Gmail password)
- `APPLICATION_TO` = `farhanp456@gmail.com`
- `SMTP_URL` = `smtps://smtp.gmail.com:465` (default)

The recipient is already configured as `farhanp456@gmail.com` unless overridden by `APPLICATION_TO`.

Never put your Gmail password or App Password into the HTML/JavaScript.
